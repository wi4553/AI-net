---
name: "🏷 Add or update a category"
about: Do you like to suggest a new project category or update an existing one?
title: ''
labels: 'category'
assignees: ''

---

<!--
Please select either to add or to update a category. Tick of with: [] -> [x]
-->

- [ ] Add category
- [ ] Update category: <!-- Category Name or ID -->

**Category details:**

<!--- 
Please state the category details that should be added or changed.
-->

- Category Title:
- Category Subtitle:

**Additional context:**

<!-- Add any other context or additional information about why this change or addition is important. -->
