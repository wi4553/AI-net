---
name: "\U0001F4AC Anything else?"
about: For questions or suggestions regarding the metadata collection or markdown generation, please refer to the best-of-lists/best-of-generator repository.
title: ''
labels: 'question'
assignees: ''

---

<!--
For questions or suggestions regarding the project metadata collection or markdown generation, please refer to the best-of-generator repository: https://github.com/best-of-lists/best-of-generator
-->

**Describe the issue:**

<!-- Describe your issue, but please be descriptive! Include screenshots, logs, code or other info to help explain your problem -->
