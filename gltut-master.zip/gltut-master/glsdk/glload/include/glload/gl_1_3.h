#ifndef OPENGL_GEN_1_3_H
#define OPENGL_GEN_1_3_H

#include "_int_gl_type.h"
#include "_int_gl_exts.h"

#include "_int_gl_1_0.h"
#include "_int_gl_1_1.h"
#include "_int_gl_1_2.h"
#include "_int_gl_1_3.h"
#endif /*OPENGL_GEN_1_3_H*/
