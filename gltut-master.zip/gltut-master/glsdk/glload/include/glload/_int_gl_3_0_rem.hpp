#ifndef OPENGL_GEN_CORE_REM3_0_HPP
#define OPENGL_GEN_CORE_REM3_0_HPP

#include "_int_load_test.hpp"
namespace gl
{
	enum
	{
		ALPHA_INTEGER                    = 0x8D97,
		CLAMP_FRAGMENT_COLOR             = 0x891B,
		CLAMP_VERTEX_COLOR               = 0x891A,
	};
	
	namespace _detail
	{
	}
	
	
}
#endif /*OPENGL_GEN_CORE_REM3_0_HPP*/
