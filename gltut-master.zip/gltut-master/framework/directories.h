#define LOCAL_FILE_DIR "data/"
#define GLOBAL_FILE_DIR "../data/"

